import java.lang.Exception;

public class UtilizadorException extends Exception {  
	
	public UtilizadorException(String message) {
		super(message);
	}
}