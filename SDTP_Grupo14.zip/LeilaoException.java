public class LeilaoException extends Exception {

	public LeilaoException(String message) {
		super(message);
	}
}